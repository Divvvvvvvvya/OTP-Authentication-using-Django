from django.contrib import admin
from .models import OTPAuth

@admin.register(OTPAuth)
class OTPAdmin(admin.ModelAdmin):
    #list_filter = ('Type',)
    #ordering = ('VitaminPresent','-Name')
    list_display=['email','OTP']
    #search_fields = ('Name',)
