from typing import Counter
from django.http.response import HttpResponseGone
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from OAuth.models import *
from smtplib import SMTP 
import getpass
import random

def mailsend(user):
    
    s=SMTP('smtp.gmail.com',587)
    s.starttls()
    s.ehlo()
    s.login("123015018@sastra.ac.in","Bharathi@2182")
    sent_from = "123015018@sastra.ac.in"
    to = [user.email]
    subject = 'Here is your OTP '
    body = str(user.OTP) + ". OTP Valid for 5 mins . Romba scene podadha okay? Bharathi Dawwwwwwwwwwwwwwwwwwww"

    email_text = """\
From: %s
To: %s
Subject: %s

%s
""" % (sent_from,",".join(to),subject,body)
    s.sendmail(sent_from,to,email_text)
    s.quit()

def index(request):
    if request.method == "GET":
        return TemplateResponse(request, "index.html")
    if request.method == "POST":
        mail = request.POST.get("Email", None)
        otp= random.randint(10000,99999)
        u1 = OTPAuth(email = mail, OTP = otp)
        try:
            mailsend(u1)
        except:
            return TemplateResponse(request, "index.html",context = { 'status' : 'Please enter a valid Email ID' })
        u1.save()
        return TemplateResponse(request, "index.html",context = { 'status' : 'Mail Successfully sent' })
   
